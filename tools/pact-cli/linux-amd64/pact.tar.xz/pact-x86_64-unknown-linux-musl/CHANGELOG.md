# Changelog

All notable changes to this project will be documented in this file.

## [0.10.9] _2026-10-14_

### 🧩 Bundled CLIs

- _(deps)_ Update rust crate pact-plugin-cli to [v0.3.1](https://github.com/pact-foundation/pact-plugins/releases/tag/pact-plugin-cli-v0.3.1) ([#150](https://github.com/pact-foundation/pact-cli/issues/150))
- _(deps)_ Update rust crate pact-broker-cli to [v0.9.0](https://github.com/pact-foundation/pact-broker-cli/releases/tag/v0.9.0) ([#155](https://github.com/pact-foundation/pact-cli/issues/155))


## [0.10.8] _2026-09-16_

### 📚 Documentation

- Fix minor changelog issue
- Add missing 0.10.7 changelog


## [0.10.7] _2026-07-13_

### 🛠️ Miscellaneous Tasks

- Dependency updates

## [0.10.6] _2026-07-13_

### 🚀 Features

- Add drift extension

### 🛠️ Miscellaneous Tasks

- _(docs)_ Correct changelog
- _(drift)_ Install to ~/.drift
- Cargo fmt
- _(drift)_ Win-arm64 no bins, ensure config dir exists
- Exit early if extension has unsupported plat/arch
- _(drift)_ Minor fixups
- _(drift)_ Clippy fixup

## [0.10.5] _2026-07-01_

### 🛠️ Miscellaneous Tasks

- _(ci)_ Add legacy-artifact publishing job

## [0.10.4] _2026-06-29_

### 🛠️ Miscellaneous Tasks

- Update distribution links ([#88](https://github.com/pact-foundation/pact-cli/issues/88))
- _(ci)_ Fix container job permissions
- _(pact-broker-cli)_ Remove deprecated arg from pactflow client

### Docs

- Add Scarf analytics pixel to README and document telemetry / opt-out (PACT-6978)

## [0.10.3] _2026-06-25_

### 🎨 Styling

- Fix rustfmt and clippy warnings

### 📚 Documentation

- Rewrite the installation section
- Collapse help output behind details blocks
- Enable Scarf telemetry pixel for pact-cli (PACT-7007) ([#86](https://github.com/pact-foundation/pact-cli/issues/86))

### 🛠️ Miscellaneous Tasks

- Add cargo-dist and release-plz pipeline

## [0.10.2] - 2026-06-02

### Bug Fixes

- Add and fix retry logic
- Wire --enable-otel as master switch for OTEL traces and logs
- Use clap-parsed external subcommand name and args for extension dispatch
- Replace SimpleLogProcessor with BatchLogProcessor for OTEL log bridge

### Miscellaneous Tasks

- Drop x86_64-pc-windows-gnu build target
- Update softprops/action-gh-release action to v2.6.2
- Replace non-breaking space with normal space
- Move and update renovate config
- Update softprops/action-gh-release action to v3

### Ci

- Reduce build time with caching and fewer integration test runs
- Add step timeout and fix unbounded wait loops in example scripts

## [0.10.0] - 2026-05-06

### Features

- Update pact-broker-cli to 0.7.0 ([#51](https://github.com/orhun/git-cliff/issues/51))

## [0.9.5] - 2026-03-13

### Bug Fixes

- Update rust crate pact-broker-cli to v0.6.3 (#43)

## [0.9.4] - 2026-03-02

### Bug Fixes

- Update rust crate reqwest-tracing to 0.7.0 ([#25](https://github.com/orhun/git-cliff/issues/25)) [skip ci]
- Update rust crate indexmap to v2 ([#34](https://github.com/orhun/git-cliff/issues/34)) [skip ci]
- Update rust crate pact-broker-cli to v0.6.2 ([#35](https://github.com/orhun/git-cliff/issues/35))

## [0.9.3] - 2026-02-23

### Bug Fixes

- Update rust crate pact-broker-cli to v0.6.1 ([#33](https://github.com/orhun/git-cliff/issues/33))

## [0.9.2] - 2026-02-11

### Bug Fixes

- Update rust crate pact-broker-cli to 0.6.0 ([#20](https://github.com/orhun/git-cliff/issues/20))

### Miscellaneous Tasks

- Update rust crate clap to v4.5.57 ([#12](https://github.com/orhun/git-cliff/issues/12)) [skip ci]
- Update rust crate clap_complete to v4.5.65 ([#13](https://github.com/orhun/git-cliff/issues/13)) [skip ci]
- Update rust crate comfy-table to v7.2.2 ([#15](https://github.com/orhun/git-cliff/issues/15)) [skip ci]
- Update rust crate serde_json to v1.0.149 ([#16](https://github.com/orhun/git-cliff/issues/16)) [skip ci]
- Update rust crate tracing-opentelemetry to v0.32.1 ([#18](https://github.com/orhun/git-cliff/issues/18)) [skip ci]
- Update rust crate trycmd to v0.15.11 ([#19](https://github.com/orhun/git-cliff/issues/19)) [skip ci]

## [0.9.1] - 2025-10-31

### Bug Fixes

- Update clap to 4.5.51

## [0.9.0] - 2025-10-25

### Features

- Add pactflow-ai / pact-ruby-standalone via extensions framework

## [0.8.0] - 2025-10-24

### Features

- Latest clis

### Miscellaneous Tasks

- Correct docker download link [ci skip]
- Cargo update
- Update readme with new options
- Add alised 1-liner install script

## [0.7.0] - 2025-10-22

### Bug Fixes

- Update pact-broker-cli to 0.2.1
- Return ExitCode throughout rather than using process exit for pact-broker-cli

### Features

- Add otel configuration
- Pact broker with otel config

### Miscellaneous Tasks

- Use sed for portability in swapping opts

### Demo

- Add ruby/rust mock/stub/verifier demos

## [0.6.0] - 2025-10-16

### Features

- Update pact-broker-cli to 0.2.0
- Rename pact-broker to broker, rename cli binary to pact ([#3](https://github.com/orhun/git-cliff/issues/3))

### Miscellaneous Tasks

- Correct env vars reused from pact-broker-cli install script

## [0.5.0] - 2025-10-10

### Features

- Simple clap cli app with subcommands
- Composed pact cli

<!-- generated by git-cliff -->
